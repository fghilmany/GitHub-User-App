package com.yukmangan.githubuser.network.github


import com.google.gson.annotations.SerializedName

class Following : ArrayList<FollowingItem>()